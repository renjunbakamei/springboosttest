CREATE VIEW VIW_FILTER_GRP_INF AS select
   a.usage_id,
   a.app_id,
   b.app_tp,
   c.grp_usage_id,
   c.grp_id,
   c.filter_tp,
   c.black_white_in,
   d.min_value,
   d.max_value,
   e.sbuf_nm,
   e.sbuf_value_begin_pos,
   e.sbuf_value_len
from
   TBL_PAR_FILTER_APP_DTL a,
   TBL_PAR_FILTER_APP_DEF b,
   TBL_PAR_FILTER_GRP_INF c,
   TBL_PAR_FILTER_GRP_DTL d,
   TBL_PAR_FILTER_GRP_DEF e
where
   a.usage_id = b.usage_id
   and a.grp_usage_id = c.grp_usage_id
   and a.grp_id = c.grp_id
   and a.grp_usage_id = d.grp_usage_id
   and a.grp_id = d.grp_id
   and a.grp_usage_id = e.grp_usage_id
order by
   c.black_white_in ASC
/
