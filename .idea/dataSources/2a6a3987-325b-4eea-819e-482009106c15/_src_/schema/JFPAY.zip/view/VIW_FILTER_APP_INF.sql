CREATE VIEW VIW_FILTER_APP_INF AS select
   a.usage_id,
   a.app_id,
   a.app_info,
   a.app_prio,
   b.app_tp
from
   TBL_PAR_FILTER_APP_INF a,
   TBL_PAR_FILTER_APP_DEF b
where
   a.eff_in = '1'
   and a.usage_id = b.usage_id
   and b.app_status='1'
 order by a.app_prio
/
