CREATE VIEW PAYCREDITACCOUNT AS select DISTINCT(j.account2), j.remark from payjnls j, PAYOPERBANKCARD p where p.CARDOWNER is null and p.cardno = j.account2 and j.msgcode = '00'
/
