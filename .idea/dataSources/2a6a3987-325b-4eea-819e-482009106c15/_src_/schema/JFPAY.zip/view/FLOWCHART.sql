CREATE VIEW FLOWCHART AS select b.tradeid,b.tradecode,b.tradename,c.flowchart from etb_sysatomictrade b,etb_sysflowchart c where c.flowid = b.tradeid

/
