CREATE TRIGGER TX_JFCL_LOG_TRAGGER
BEFORE INSERT
  ON TX_JFCL_LOG
FOR EACH ROW
  begin
select TX_ID_sequence.nextval into:New.ID from dual;
end;
/
