CREATE TRIGGER TX_PREP_LOG_TRAGGER
BEFORE INSERT
  ON TX_PREP_LOG
FOR EACH ROW
  begin
select TX_PREP_LOG_sequence.nextval into:New.ID from dual;
end;
/
