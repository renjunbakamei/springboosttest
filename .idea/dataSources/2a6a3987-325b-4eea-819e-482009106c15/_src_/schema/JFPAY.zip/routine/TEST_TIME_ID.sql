CREATE function test_time_id
(localdate string, localtime string)
return number
as
tmp_num number;
tmp_id number;
begin

  select count(t.t_id) into tmp_num
  from test_plan p, test_time t, test_date d
  where p.fk_test_time=t.t_id
  and p.fk_test_date=d.d_id
  and d.t_date=localdate
  and localtime>=t.s_time
  and localtime<=t.e_time;

  if tmp_num = 0 then

    if localtime<='091500' then
      select t.t_id into tmp_id
      from test_time t
      where t.e_time = '085000';
    else
      if localtime>'220000' then
        select p.fk_test_time into tmp_id
        from test_plan p, test_time t, test_date d
        where p.fk_test_time=t.t_id
          and p.fk_test_date=d.d_id
          and d.t_date=localdate
          and t.e_time='220000';
      else
        tmp_id:= null;
      end if;
    end if;
  else
    select p.fk_test_time into tmp_id
    from test_plan p, test_time t, test_date d
      where p.fk_test_time=t.t_id
      and p.fk_test_date=d.d_id
      and d.t_date=localdate
      and localtime>=t.s_time
      and localtime<=t.e_time
      and rownum=1;
  end if;

  return tmp_id;
end;
/
