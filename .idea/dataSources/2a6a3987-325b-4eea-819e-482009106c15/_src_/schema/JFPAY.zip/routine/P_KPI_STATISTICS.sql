CREATE procedure p_kpi_statistics is
  hand_start_date varchar(20); --开始日期
  hand_stop_date  varchar(20); --结束日期
  --  ds_trans_num     number(1);--点刷执行标示
  ds_trans_value     varchar(100); --点刷交易量值
  ds_while_cs        number(2); --点刷循环次数
  ds_hand_start_date varchar(20); --点刷开始日期
  ds_hand_stop_date  varchar(20); --点刷结束日期
  ds_active_rate     varchar(20); --点刷活跃率
  zd_hand_stop_date  varchar(20); --终端结束日期
  xz_my_num          varchar(20); --终端数
  xz_phone_num       varchar(20); --新增手机数
  xz_user_num        varchar(20); --新增用户数
  payjnls_num        number(10); --用于统计交易笔数
  paycxjnls_num      number(10); --用于统计交易笔数
  ds_trans_flow_num  number(10); --用于统计交易笔数
  hpstjnl_num        number(10); --用于统计交易笔数
  trans_num          number(10); --交易笔数
  active_user_num    varchar(20); --活跃用户
  hand_start_date_2  varchar(20); --开始日期(前两个月)
  hand_stop_date_2   varchar(20); --结束日期(前两个月)
  loss_rate          varchar(20); --流失率
  kjd_cost           varchar(20); --开，即，大成本
  wd_cost            varchar(20); --无，点成本
begin
  select to_char(trunc(add_months(sysdate, -1), 'mm'), 'yyyymmdd')
    into hand_start_date
    from dual;
  select to_char(last_day(add_months(sysdate, -1)), 'yyyymmdd')
    into hand_stop_date
    from dual;

  --点刷交易量
  -- select count(1) into ds_trans_num  from kpi_status t1 where t1.hand_status='1' and t1.hand_start_date=hand_start_date;
  --if ds_trans_num<1 then

  select to_char(sum(s.amount / 100), 'FM9999999999990.00')
    into ds_trans_value
    from jf_pmo.ds_trans_flow s
   where s.local_date >= hand_start_date
     and s.local_date <= hand_stop_date
     and s.server_code = '400034';

  insert into kpi_info
  values
    ('DS_TRANS_NUM', '点刷交易量', ds_trans_value);
  insert into kpi_status
  values
    ('DS_TRANS_NUM', hand_start_date, '1', '点刷交易量', hand_stop_date);
  commit;
  --end if;

  --点刷机器活跃率

  ds_while_cs := 1;
  while ds_while_cs <= 12 loop
    select to_char(trunc(add_months(sysdate, -ds_while_cs), 'mm'),
                   'yyyymmdd')
      into ds_hand_start_date
      from dual;
    select to_char(last_day(add_months(sysdate, -ds_while_cs)), 'yyyymmdd')
      into ds_hand_stop_date
      from dual;
  
    --前第1个月售出点刷活跃率
    select (select count(distinct s.psam)
              from jf_pmo.pmo_agent_range   s,
                   jf_pmo.psam_customer_rel c,
                   jf_pmo.ds_trans_flow     d
             where s.range_create_time >= ds_hand_start_date
               and s.create_time <= ds_hand_stop_date
               and s.psam = substr(c.psam_id, 0, 15)
               and c.customer_mobile = d.mobile_no
               and d.local_date >= ds_hand_start_date
               and d.local_date <= ds_hand_stop_date) /
           (select count(1)
              from jf_pmo.pmo_agent_range ps
             where ps.range_create_time >= ds_hand_start_date
               and ps.create_time <= ds_hand_stop_date)
      into ds_active_rate
      from dual;
    insert into kpi_info
    values
      ('DS_TRANS_NUM',
       '前第' || ds_while_cs || '个月售出点刷活跃率',
       ds_active_rate);
    insert into kpi_status
    values
      ('DS_TRANS_NUM',
       hand_start_date,
       '1',
       '前第' || ds_while_cs || '个月售出点刷活跃率',
       hand_stop_date);
    ds_while_cs := ds_while_cs + 1;
    commit;
  end loop;

  --新增秘钥数
  select to_char(last_day(add_months(sysdate, -1)) + 1, 'yyyymmdd')
    into zd_hand_stop_date
    from dual;

  select count(1)
    into xz_my_num
    from jfpay.paypsam p, jfpay.payterminal pt
   where p.psamid = pt.psamid
     and pt.timestamp >= hand_start_date
     and pt.timestamp < zd_hand_stop_date;

  insert into kpi_info values ('XZ_MY_NUM', '新增密钥数', xz_my_num);
  insert into kpi_status
  values
    ('XZ_MY_NUM', hand_start_date, '1', '新增密钥数', hand_stop_date);
  commit;

  --新增手机号

  select count(*)
    into xz_phone_num
    from jfpay.etb_sysservicelog p
   where p.servcode = '100001'
     and p.localdate >= hand_start_date
     and p.localdate <= hand_stop_date;
  insert into kpi_info values ('XZ_PHONE_NUM', '新手机号数', xz_phone_num);
  insert into kpi_status
  values
    ('XZ_PHONE_NUM', hand_start_date, '1', '新手机号数', hand_stop_date);
  commit;

  --新增实名用户数
  SELECT count(*)
    into xz_user_num
    FROM jfpay.PREP_PERSONALINFO p
   where p.auditflag = '3'
     and p.createdate >= hand_start_date
     and p.createdate <= hand_stop_date;
  insert into kpi_info values ('XZ_USER_NUM', '新实名用户数', xz_user_num);
  insert into kpi_status
  values
    ('XZ_USER_NUM', hand_start_date, '1', '新实名用户数', hand_stop_date);
  commit;

  --交易笔数

  select count(1)
    into payjnls_num
    from jfpay.payjnls p
   where p.localdate >= hand_start_date
     and p.localdate <= hand_stop_date;
  select count(1)
    into paycxjnls_num
    from jfpay.paycxjnls p
   where p.localdate >= hand_start_date
     and p.localdate <= hand_stop_date;
  select count(1)
    into ds_trans_flow_num
    from jf_pmo.ds_trans_flow d
   where d.local_date >= hand_start_date
     and d.local_date <= hand_stop_date;
  --select count(1) into hpstjnl_num from jfpay.hpstjnl h where h.AC_DT>=hand_start_date and h.AC_DT<=hand_stop_date;

  trans_num := payjnls_num + paycxjnls_num + ds_trans_flow_num +
               hpstjnl_num;
  insert into kpi_info values ('TRANS_NUM', '交易笔数', trans_num);
  insert into kpi_status
  values
    ('TRANS_NUM', hand_start_date, '1', '交易笔数', hand_stop_date);
  commit;

  --当月活跃用户

  select count(distinct(p.termid))
    into active_user_num
    from jfpay.etb_sysservicelog p
   where p.localdate >= hand_start_date
     and p.localdate <= hand_stop_date;
  insert into kpi_info values ('TRANS_NUM', '活跃用户', active_user_num);
  insert into kpi_status
  values
    ('TRANS_NUM', hand_start_date, '1', '活跃用户', hand_stop_date);
  commit;

  --存量开店宝、即付宝流失率
  select to_char(trunc(add_months(sysdate, -2), 'mm'), 'yyyymmdd')
    into hand_start_date_2
    from dual;
  select to_char(last_day(add_months(sysdate, -2)), 'yyyymmdd')
    into hand_stop_date_2
    from dual;
  select ((select to_char(sum(p.amount / 100), 'FM9999999999990.00') amount
             from (select row_number() over(partition by a.localdate, a.localtime, a.locallogno order by a.localdate, a.localtime, a.locallogno) as row_number,
                          a.servcode,
                          a.amount,
                          a.localdate,
                          a.localtime,
                          a.locallogno,
                          a.fee,
                          a.productid,
                          a.merchantid
                     from jfpay.payjnls a
                    where a.status = '0'
                      and a.paytag = '0'
                      and a.msgcode = '0000'
                      and a.localdate >= hand_start_date
                      and a.localdate <= hand_stop_date) p
            where p.row_number = 1) /
         (select to_char(sum(p.amount / 100), 'FM9999999999990.00') amount
             from (select row_number() over(partition by a.localdate, a.localtime, a.locallogno order by a.localdate, a.localtime, a.locallogno) as row_number,
                          a.servcode,
                          a.amount,
                          a.localdate,
                          a.localtime,
                          a.locallogno,
                          a.fee,
                          a.productid,
                          a.merchantid
                     from jfpay.payjnls a
                    where a.status = '0'
                      and a.paytag = '0'
                      and a.msgcode = '0000'
                      and a.localdate >= hand_start_date_2
                      and a.localdate <= hand_stop_date_2) p
            where p.row_number = 1)) * 100
    into loss_rate
    from dual;

  insert into kpi_info
  values
    ('LOSS_TATE', '存量开店宝,即付宝流失率', loss_rate);
  insert into kpi_status
  values
    ('LOSS_TATE',
     hand_start_date,
     '1',
     '存量开店宝,即付宝流失率',
     hand_stop_date);
  commit;

  --开店宝/即付宝/大pos垫资成本

  select sum(cb_amount)
    into kjd_cost
    from (select outchannel,
                 inchannel,
                 sum(amount),
                 count(amount),
                 sum(case
                       when outchannel = 'MSSS-DBQ' then
                        amount * 0.00015
                       when outchannel = 'PA-UNIONPAY' then
                        amount * 0.00015
                       when outchannel = 'PA-UNIONPAY-T1' then
                        amount * 0.00015
                       when outchannel = 'MSDZ-DBQ' then
                        amount * 0.00015
                       when outchannel = 'DLMS-DBQ' then
                        amount * 0.000135
                       when outchannel = 'MS-DBQ' then
                        amount * 0.000135
                       when outchannel = 'ZJUNIONPAY' then
                        amount * 0.000135
                       when outchannel = 'UNIONPAY' then
                        0.5
                       else
                        0
                     end) as cb_amount
            from payacct.rhdf_list
           where origdate >= hand_start_date
             and origdate <= hand_stop_date
             and inchannel in ('6', 'DBQ', 'POS-D0')
           group by outchannel, inchannel) dual;

  insert into kpi_info
  values
    ('KJD_COST', '开店宝/即付宝/大pos垫资成本', kjd_cost);
  insert into kpi_status
  values
    ('KJD_COST',
     hand_start_date,
     '1',
     '开店宝/即付宝/大pos垫资成本',
     hand_stop_date);
  commit;

  --无卡支付/点刷资金成本

  select sum(cb_amount)
    into wd_cost
    from (select s.servcode,
                 p.outchannel,
                 p.inchannel,
                 sum(p.amount),
                 count(p.amount),
                 sum(case
                       when p.outchannel = 'MSSS-DBQ' then
                        p.amount * 0.00015
                       when p.outchannel = 'PA-UNIONPAY' then
                        p.amount * 0.00015
                       when p.outchannel = 'PA-UNIONPAY-T1' then
                        p.amount * 0.00015
                       when p.outchannel = 'MSDZ-DBQ' then
                        p.amount * 0.00015
                       when p.outchannel = 'DLMS-DBQ' then
                        p.amount * 0.000135
                       when p.outchannel = 'MS-DBQ' then
                        p.amount * 0.000135
                       when p.outchannel = 'ZJUNIONPAY' then
                        p.amount * 0.000135
                       when outchannel = 'UNIONPAY' then
                        0.5
                       else
                        0
                     end) as cb_amount
            from jfpay.payjnls s, payacct.rhdf_list p
           where s.localdate = p.origdate
             and s.localtime = p.origtime
             and s.locallogno = p.origlogno
             and s.servcode in ('400034', '400035')
             and s.tradecode = 'HM0003'
             and origdate >= hand_start_date
             and origdate <= hand_stop_date
           group by outchannel, inchannel, servcode) dual;

  insert into kpi_info
  values
    ('WD_COST', '无卡支付/点刷资金成本', wd_cost);
  insert into kpi_status
  values
    ('WD_COST',
     hand_start_date,
     '1',
     '无卡支付/点刷资金成本',
     hand_stop_date);
  commit;
  
  for c_jfb_data in (

--------即付宝（不包括无卡）
select sum(ft.trd_amount) as amount,
       decode(po.id,
              '3',
              '即付宝交易量(福建即富子公司1)',
              '45',
              '即付宝交易量(福建即富子公司)',
              '47',
              '即付宝交易量(广东即富子公司)',
              '48',
              '即付宝交易量(浙江即富子公司)',
              '8',
              '即付宝交易量(浙江即富子公司1)',
              '46',
              '即付宝交易量(江苏即富子公司)',
              '55',
              '即付宝交易量(胡洁统)') as org_name
  from jf_pmo.fr_splitting          ft,
       jf_pmo.pmo_agent             t,
       jf_pmo.pmo_institution       po,
       jf_pmo.pmo_institution_agent pt
 where t.id = pt.agent_id
   and po.id = pt.institution_id
   and po.id in ('3', '45', '47', '48', '8', '46', '55')
   and ft.agent_id = t.id
   and ft.servcode not in ('400018', '400035')
   and ft.date_range >= hand_start_date
   and ft.date_range <= hand_stop_date
 group by po.id) loop 
 
   insert into kpi_info
  values
    ('WD_COST', c_jfb_data.org_name, c_jfb_data.amount);
  insert into kpi_status
  values
    ('WD_COST',
     hand_start_date,
     '1',
     c_jfb_data.org_name,
     hand_stop_date);
  commit;
 end loop;
 
 
 --------开店宝（不包括无卡）
 for c_kdb_data in (
select sum(ft.trd_amount) as amount,
       decode(po.id,
              '3',
              '开店宝交易量(福建即富子公司1)',
              '45',
              '开店宝交易量(福建即富子公司)',
              '47',
              '开店宝交易量(广东即富子公司)',
              '48',
              '开店宝交易量(浙江即富子公司)',
              '8',
              '开店宝交易量(浙江即富子公司1)',
              '46',
              '开店宝交易量(江苏即富子公司)',
              '55',
              '开店宝交易量(胡洁统)') as org_name
  from jf_pmo.fr_splitting          ft,
       jf_pmo.pmo_agent             t,
       jf_pmo.pmo_institution       po,
       jf_pmo.pmo_institution_agent pt
 where t.id = pt.agent_id
   and po.id = pt.institution_id
   and po.id in ('3', '45', '47', '48', '8', '46', '55')
   and ft.agent_id = t.id
   and ft.servcode ='400018'
   and ft.date_range >= hand_start_date
   and ft.date_range <= hand_stop_date
 group by po.id
) loop 
 
   insert into kpi_info
  values
    ('WD_COST', c_kdb_data.org_name, c_kdb_data.amount);
  insert into kpi_status
  values
    ('WD_COST',
     hand_start_date,
     '1',
     c_kdb_data.org_name,
     hand_stop_date);
  commit;
 end loop;


--点刷
for c_ds_data in (select sum(ft.trd_amount) as amount,
       decode(po.id,
              '3',
              '点刷交易量(福建即富子公司1)',
              '45',
              '点刷交易量(福建即富子公司)',
              '47',
              '点刷交易量(广东即富子公司)',
              '48',
              '点刷交易量(浙江即富子公司)',
              '8',
              '点刷交易量(浙江即富子公司1)',
              '46',
              '点刷交易量(江苏即富子公司)',
              '55',
              '点刷交易量(胡洁统)') as org_name
  from jf_pmo.ds_fr_splitting       ft,
       jf_pmo.pmo_agent             t,
       jf_pmo.pmo_institution       po,
       jf_pmo.pmo_institution_agent pt
 where t.id = pt.agent_id
   and po.id = pt.institution_id
   and po.id in ('3', '45', '47', '48', '8', '46', '55')
   and ft.agent_id = t.id
   and ft.servcode = '400034'
   and ft.date_range >= hand_start_date
   and ft.date_range <= hand_stop_date
 group by po.id) loop 
 
   insert into kpi_info
  values
    ('WD_COST', c_ds_data.org_name, c_ds_data.amount);
  insert into kpi_status
  values
    ('WD_COST',
     hand_start_date,
     '1',
     c_ds_data.org_name,
     hand_stop_date);
  commit;
 end loop;


end;
/
