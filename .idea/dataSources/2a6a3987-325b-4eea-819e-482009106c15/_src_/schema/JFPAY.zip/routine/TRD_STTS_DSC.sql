CREATE function trd_stts_dsc
(status string)
return string
as
status_desc varchar2(12);
begin

  case status
       when '0' then status_desc:='交易正常结束';
       when '1' then status_desc:='交易中';
       when '2' then status_desc:='交易冲正结束';
  end case;

  return status_desc;

end;
/
