CREATE PROCEDURE employer_details
IS
  CURSOR customerEmail IS
  SELECT email FROM PAYCUSTOMER;
  var_email varchar(30);
BEGIN
  dbms_output.put_line('!!!!!!');
  FOR email_rec in customerEmail
  LOOP
    dbms_output.put_line(email_rec.email);
  END LOOP;
END;
/
