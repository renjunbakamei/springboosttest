CREATE PROCEDURE USER_UPGRADE(return_code out varchar2,reutrn_msg out varchar2)  --每天升级跑批 by huangmq20160419
is
acount number(20);
fenduan  number(5);
fenb number(5);
begin
      for c_date in (
select serial_source,amount,user_code,money_source,money_type,account_status
  from (select (select min(SERIAL_SOURCE)
                  from account_new.t_account_bill
                 where recharge_id = t1.recharge_id) as SERIAL_SOURCE,
               amount,
               user_code,
               MONEY_SOURCE,
               MONEY_TYPE,
               (select ACCOUNT_STATUS
                  from account_new.t_account
                 where user_code = t1.user_code) as ACCOUNT_STATUS
          from (select sum(balance_now) as amount,
                       recharge_id,
                       user_code,
                       MONEY_SOURCE,
                       PSAM_NUMBER,
                       MONEY_TYPE
                  from account_new.t_account_recharge
                 where user_code = '18516071531'
                 and TRADE_DATE >'20151230'
                 group by recharge_id，user_code,
                          MONEY_SOURCE,
                          PSAM_NUMBER,
                          MONEY_TYPE) t1
         where t1.amount > 0
           and t1.MONEY_TYPE != '03')
 where ACCOUNT_STATUS = '01') loop

 if mod(acount,10000)=0 then
    fenduan:=fenduan+1;
 end if;

  acount:= acount+1;

  select lpad(acount,6,'0') into  from dual;
 insert into T_ACCOUNT_bak values(user_code,amount,serial_source,money_source,money_type,account_status,fenduan,'0',acount);

 end loop;
    return_code:='0000';
    reutrn_msg:='成功';

end;
/
