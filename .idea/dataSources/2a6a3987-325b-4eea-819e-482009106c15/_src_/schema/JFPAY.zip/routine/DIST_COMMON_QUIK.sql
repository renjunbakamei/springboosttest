CREATE function dist_common_quik(servicecode in varchar2,tradecode in varchar2,productid in varchar2)
return varchar2 as
  Result varchar2(100);
begin
    if (servicecode='100022') then Result:='手机充值(刷卡)';
       end if;
    if(servicecode='100025') then Result:='支付宝充值(刷卡)';
       end if;
    if(servicecode='100031' and tradecode='AXC003') then Result:='信用卡还款(刷卡)--实时还款';
       end if;
    if(servicecode='100031' and tradecode='HCC001') then Result:='信用卡还款(刷卡)--非实时还款';
       end if;
    if(servicecode='100031' and tradecode='HCC003') then Result:='信用卡还款(刷卡)--实时还款';
       end if;
    if(servicecode='100034') then Result:='我要付款(刷卡)';
       end if;  
    if(servicecode='100037' and productid='0000000000') then Result:='转帐（普通）';
       end if;
    if(servicecode='100037' and productid='0000000001') then Result:='转帐（快速）';
       end if;
    if(servicecode='100040') then Result:='个贷还款(刷卡)';
       end if;  
    if(servicecode='100084') then Result:='火车票支付(刷卡)';
       end if;  
    if(servicecode='200003') then Result:='福彩购买(刷卡)';
       end if;  
       
  return Result;
end dist_common_quik;
/
