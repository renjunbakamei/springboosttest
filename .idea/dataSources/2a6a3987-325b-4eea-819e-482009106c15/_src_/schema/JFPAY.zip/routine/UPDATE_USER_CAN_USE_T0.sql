CREATE procedure update_user_can_use_T0(type_id in number) as
last_date varchar2(8); --统计的日期
localdate1 varchar2(8); --跑批日期
begin
  --条件一：指定时间之后注册的新用户，注册满90天；
  --条件二：指定时间之后注册的新用户，连续30天有正常交易；
  dbms_output.put_line('now:'||to_char(sysdate,'yyyyMMddHH24miss'));
  last_date:= to_char(sysdate-1, 'yyyyMMdd');
  localdate1:= to_char(sysdate, 'yyyyMMdd');
  dbms_output.put_line('coming in!'||'date:'||last_date);
  --将昨天注册的用户插入统计表中
  insert into new_user_continued_pay  select s.username,0,'0',s.customerregdate ,last_date  from paycustomer s where s.customerregdate=last_date;
  commit;
  --根据流水表,计算用户的累计交易天数
  update new_user_continued_pay ts set ts.pay_days=ts.pay_days+1,ts.last_date=localdate1 where ts.last_date<localdate1 and ts.status='0' and exists (select 1 from(
  select distinct s.mobileno as userid from payjnls s where s.localdate=last_date and s.paytag='0' union all
  select distinct s.account2 as userid from payjnls s where s.localdate=last_date and s.paytag='0')ks where ts.mobileno=ks.userid
  );
  commit;
  --中间有一天断了,置为0
  update new_user_continued_pay ts set ts.pay_days=0,ts.last_date=localdate1 where ts.last_date<localdate1 and ts.status='0' and not exists (select 1 from(
  select distinct s.mobileno as userid from payjnls s where s.localdate=last_date and s.paytag='0' union all
  select distinct s.account2 as userid from payjnls s where s.localdate=last_date and s.paytag='0')ks where ts.mobileno=ks.userid
  );
  commit;
  --满足连续30天交易的用户
  update new_user_continued_pay ts set ts.status='1',ts.last_date=localdate1 where ts.pay_days>=30 and ts.status='0';
  commit;
    if type_id=1 then --满足条件一或者条件二即可做T+0
    --dbms_output.put_line('1111111');
     update paycustomer t
            set t.blank4 = substr(t.blank4, 0, 1) || '1' || substr(t.blank4, 3, 28)
            where substr(t.blank4, 2, 1) = '0'
                 and ( floor(sysdate - to_date(t.customerregdate, 'yyyymmdd')) >=90
                 or t.username in ( select ar.mobileno from new_user_continued_pay ar where ar.status='1'  ));
      commit;
  elsif type_id=2 then --满足条件一且满足条件二才能做T+0
    --dbms_output.put_line('2222222');
     update paycustomer t
            set t.blank4 = substr(t.blank4, 0, 1) || '1' || substr(t.blank4, 3, 28)
            where substr(t.blank4, 2, 1) = '0'
                 and floor(sysdate - to_date(t.customerregdate, 'yyyymmdd')) >=90
                 and t.username in (select ar.mobileno from new_user_continued_pay ar where ar.status='1');
      commit;
  elsif type_id=3 then --满足条件一才能做T+0
    --dbms_output.put_line('33333333');
     update paycustomer t
            set t.blank4 = substr(t.blank4, 0, 1) || '1' || substr(t.blank4, 3, 28)
            where substr(t.blank4, 2, 1) = '0'
                 and floor(sysdate - to_date(t.customerregdate, 'yyyymmdd')) >=90;
    commit;
  else --满足条件二才能做T+0
    --dbms_output.put_line('44444444');
    update paycustomer t
            set t.blank4 = substr(t.blank4, 0, 1) || '1' || substr(t.blank4, 3, 28)
            where substr(t.blank4, 2, 1) = '0'
                 and t.username in (select ar.mobileno from new_user_continued_pay ar where ar.status='1');
    commit;
  end if;

  commit;
  dbms_output.put_line('now:'||to_char(sysdate,'yyyyMMddHH24miss'));
end;
/
