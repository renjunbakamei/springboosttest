CREATE procedure test3
is
begin
  dbms_output.put_line(TO_CHAR(121, '009'));
end;
/
