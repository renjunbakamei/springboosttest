CREATE PROCEDURE USER_UPGRADE_ALL--跑一次历史数据 by huangmq20160419
is
mobileno varchar2(32); --用户手机号
counts number(10); --单日信用卡验证成功次数
nums number(3); --判断是否存在数据
viplv number(10); --用户的等级
customertag varchar2(1); --用户实名认证标志
maxId number(20); --短信列表用户ID
viplv_out number(10); --用户升级后等级
t0_lv_in number(10); --用户升级前T0等级
t0_lv_out number(10);--用户升级后T0等级
localdate varchar2(8); --统计的日期
sndmsg number(1); --是否发送通知短信标志： 0不发送;1发送
rs SYS_REFCURSOR;
begin
localdate:= to_char(sysdate-1, 'yyyyMMdd');
open rs for select s.mobileno,count(1) as nums from credit_card_identification s where s.identification_state='S' and s.card_source='auth' group by s.mobileno ;
loop
    FETCH rs into mobileno,counts;
    exit when rs%NOTFOUND;
    viplv_out:=0;
    t0_lv_out:=0;
    sndmsg:=0;
    select t.viplevel, customertag into viplv, customertag from paycustomer t where t.username=mobileno;
    t0_lv_in:=mod(viplv,1000);
    IF counts=1 then  --只验证成功1张信用卡
       dbms_output.put_line('1111:'||t0_lv_in);
       if t0_lv_in < 201 then --用户提现额度<3万
          dbms_output.put_line(viplv);
          viplv_out:=viplv-t0_lv_in+301;--升级为3万，并且发送短信
          t0_lv_out:=301;
          sndmsg:=1;
       elsif  t0_lv_in = 201 then
          dbms_output.put_line('201====='||viplv);--用户提现额度=3万
          --viplv_out:=trunc(viplv/1000)*1000+301;--等级升为3万，但不发送短信
          viplv_out:=viplv-t0_lv_in+301;
          t0_lv_out:=301;
       --总的不会升为302
       --elsif  t0_lv_in = 301 then --等级为3万，升级为5万,并且发送短信
       --  dbms_output.put_line('301====='||viplv);
       --  --viplv_out:=trunc(viplv/1000)*1000+302;--发送短信
       --  viplv_out:=viplv-t0_lv_in+302;
       --  t0_lv_out:=302;
       --  sndmsg:=1;
       else
         dbms_output.put_line(mobileno||'~1用户等级:'||viplv||'不升级');
         continue;
       end if;
    else  --验证成功信用卡大于1张
       dbms_output.put_line('22222:'||counts);
       if t0_lv_in <= 201 then --用户提现额度<=3万
          dbms_output.put_line('<=201====='||viplv);
          viplv_out:=viplv-t0_lv_in+302;--升级为5万，并且发送短信
          t0_lv_out:=302;
          sndmsg:=1;
       elsif  t0_lv_in = 202 then
          dbms_output.put_line('202====='||viplv);--用户提现额度=5万,升级不发送通知短信
          viplv_out:=viplv-t0_lv_in+302;
          t0_lv_out:=302;
          sndmsg:=0;
       elsif  t0_lv_in = 301 then --等级升为3万，升级为5万,并且发送短信
         dbms_output.put_line('301====='||viplv);
         viplv_out:=viplv-t0_lv_in+302;
         t0_lv_out:=302;
         sndmsg:=1;
       else
         dbms_output.put_line(mobileno||'~2用户等级:'||viplv||'不升级');
         continue;
       end if;
    end if;
    if viplv_out >0 then  --升级用户
      dbms_output.put('start升级用户:'||mobileno||',viplv_out:'||viplv_out);
      update paycustomer t set t.viplevel=viplv_out where t.username=mobileno;
      select max(s.id) into maxId from user_lv_records s;  --获取ID
      dbms_output.put('id='||maxid);
      if customertag='3' then
        customertag:='A';
      else
        customertag:='O';
      end if;
      nums:=0;
      select count(1) into nums from user_lv_records t where t.user_type=customertag and t.mobile_no=mobileno and t.user_lv=t0_lv_out and t.status=3;
      if nums >0 then  --数据已存在
        update user_lv_records t set t.update_time=to_char(sysdate , 'yyyyMMddHHmmss') where t.user_type=customertag and t.mobile_no=mobileno and t.user_lv=t0_lv_out and t.status=3;
        continue;
      end if;
      if sndmsg =1 then --发送短信
        insert into user_lv_records (ID, USER_TYPE, MOBILE_NO, USER_LV, SUC_TRADE_TIMES, SAFE_TRADE_DAYS, LATEST_TRADE_TIME, START_DAY_COUNT_TIME, STATUS, CREATE_TIME, UPDATE_TIME, SUC_TRADE_AMOUNT, RUN_TIME)
               values (maxId+1, customertag, mobileno, t0_lv_out, null, 0, null,localdate , 3, to_char(sysdate , 'yyyyMMddHHmmss'), to_char(sysdate , 'yyyyMMddHHmmss'), 0, to_char(sysdate, 'yyyyMMdd'));
      else --不发送短信
         insert into user_lv_records (ID, USER_TYPE, MOBILE_NO, USER_LV, SUC_TRADE_TIMES, SAFE_TRADE_DAYS, LATEST_TRADE_TIME, START_DAY_COUNT_TIME, STATUS, CREATE_TIME, UPDATE_TIME, SUC_TRADE_AMOUNT, RUN_TIME)
               values (maxId+1, customertag, mobileno, t0_lv_out, null, 0, null,null ,      3, to_char(sysdate , 'yyyyMMddHHmmss'), to_char(sysdate , 'yyyyMMddHHmmss'), 0, to_char(sysdate, 'yyyyMMdd'));
      end if;
    end if;
    commit;
    dbms_output.put_line(mobileno||'升级结束,viplv_out:'||viplv_out||',t0_lv_out:'||t0_lv_out);
end loop;
end;
/
