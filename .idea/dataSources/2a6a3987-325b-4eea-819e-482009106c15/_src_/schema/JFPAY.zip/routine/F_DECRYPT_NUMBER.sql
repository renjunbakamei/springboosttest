CREATE function f_decrypt_number (encrypted_raw IN RAW)
 return varchar2 is
 decrypted_raw raw(16);
 key_number number(8):=32432432;
 key_raw RAW(32):=UTL_RAW.cast_from_number(key_number);
 begin
 decrypted_raw := DBMS_CRYPTO.DECRYPT
 (
 src => encrypted_raw,
 typ => DBMS_CRYPTO.HASH_MD5,
 key => key_raw
);
 return decrypted_raw;
 END;


/
