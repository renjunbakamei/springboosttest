CREATE function channelparam_name(code string)
return string
as
t_number varchar2(32);
begin
  select e.channelname into t_number from channelparam e where e.channelnumber=code and rownum=1;
  return '(' || t_number || ')';
end;
/
