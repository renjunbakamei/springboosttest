CREATE procedure test_proc()
/
