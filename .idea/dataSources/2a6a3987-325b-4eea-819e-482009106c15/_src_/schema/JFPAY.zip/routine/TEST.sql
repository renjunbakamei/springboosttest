CREATE procedure test(x in number) is
begin
if x >0 then
begin
x := 0 - x;
end;
end if;
else
begin
x: = 1;
end;
end if;
end test;
/
