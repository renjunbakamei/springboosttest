CREATE procedure MYPROC as
begin
insert into MY_TEST values(sysdate);
end;

/
