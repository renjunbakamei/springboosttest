CREATE function jfpayfee
(servcode string, localdate string, localtime string,locallogno string, fee number)
return string
as
tmp_fee number;
tmp_div number;
begin

  if servcode='100032' or servcode='100033' or servcode='100034' then
     select count(*) into tmp_fee from payacct.acctxnbook a where a.txndate=localdate and a.txntime=localtime and a.txnlogno=locallogno;
     if tmp_fee = 0 then
        select fee into tmp_fee from dual;
     else
        select nvl(a.txnfee2, fee) into tmp_fee from payacct.acctxnbook a where a.txndate=localdate and a.txntime=localtime and a.txnlogno=locallogno;
     end if;
     tmp_div := 1;
  else
     select fee into tmp_fee from dual;
     tmp_div := 100;
  end if;

  return to_char(trunc(tmp_fee/tmp_div, 2), 'FM99990.00');

end;
/
