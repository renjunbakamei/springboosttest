CREATE procedure OutterProc
is
  begin
    InnerProc;
  end;
/
