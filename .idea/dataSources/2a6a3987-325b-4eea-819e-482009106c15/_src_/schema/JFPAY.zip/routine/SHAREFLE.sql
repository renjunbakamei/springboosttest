CREATE PROCEDURE SHAREFLE IS
v_MyFileHandle UTL_FILE.FILE_TYPE;
BEGIN
v_MyFileHandle := UTL_FILE.FOPEN('D:\oracle_file','HELLO.TXT','w');
UTL_FILE.PUT_LINE(v_MyFileHandle, 'Hello Again for the Second Time! ' || TO_CHAR(SYSDATE,'MM-DD-YY HH:MI:SS AM'));
UTL_FILE.FCLOSE(v_MyFileHandle);
END;
/
