CREATE function srvc_name (serv_code string)
return string
as
srvc_name  varchar2(32);
begin

  select e.servname into srvc_name from ETB_SYSCORESERVICE e where e.servcode=serv_code;

  return '(' || srvc_name || ')';

end;
/
