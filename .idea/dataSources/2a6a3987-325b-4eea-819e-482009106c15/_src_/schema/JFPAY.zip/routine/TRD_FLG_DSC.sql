CREATE function trd_flg_dsc
(flag string)
return string
as
flag_desc varchar2(12);
begin
          
  case flag
       when '0' then flag_desc:='正常交易';
       when '1' then flag_desc:='交易被冲正';
       when '2' then flag_desc:='交易被撤销';
       when '3' then flag_desc:='交易被退货';
       when '4' then flag_desc:='退货失败';
       when '9' then flag_desc:='冲正失败';
       when 'R' then flag_desc:='交易需要冲正';
       when 'F' then flag_desc:='交易失败';
       when 'Z' then flag_desc:='退款中';
       when 'P' then flag_desc:='可在退款';
       when 'T' then flag_desc:='退款成功';
       else flag_desc := '';
  end case;

  return flag_desc;

end;
/
