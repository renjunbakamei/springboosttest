CREATE function f_Encrypt_number(number_in in varchar2) return raw is
 number_in_raw RAW(128):=UTL_I18N.STRING_TO_RAW(number_in,'AL32UTF8');
 key_number number(32):=32432432343243279898;
 key_raw RAW(128):=UTL_RAW.cast_from_number(key_number);
 encrypted_raw RAW(128);
 begin
 encrypted_raw:=dbms_crypto.Encrypt(src=>number_in_raw,typ=>DBMS_CRYPTO.DES_CBC_PKCS5,key=>key_raw);
 return encrypted_raw;
 end;
/
