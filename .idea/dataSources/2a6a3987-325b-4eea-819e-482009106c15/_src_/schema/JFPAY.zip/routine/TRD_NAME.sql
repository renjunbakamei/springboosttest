CREATE function trd_name(code string)
return string
as
t_name varchar2(32);
begin

  select e.tradename into t_name from ETB_SYSATOMICTRADE e where e.tradecode=code and rownum=1;
  return '(' || t_name || ')';

end;
/
