CREATE PROCEDURE ds_test
IS
  CURSOR cur IS
 -- select dtf.mobile_no,dtf.amount,acr.agent_id from jf_pmo.ds_trans_flow dtf left join jf_pmo.AGENT_CUSTOMER_REL acr on dtf.mobile_no=acr.customer_mobile where dtf.local_date='20160825';
 select acr.agent_id from jf_pmo.AGENT_CUSTOMER_REL acr;
BEGIN
  --dbms_output.put_line('!!!!!!');
  for temp in cur
  LOOP
     --dbms_output.put_line(temp.agent_id);
      dbms_output.put_line('!!!!!!');
  END LOOP;
END;
/
