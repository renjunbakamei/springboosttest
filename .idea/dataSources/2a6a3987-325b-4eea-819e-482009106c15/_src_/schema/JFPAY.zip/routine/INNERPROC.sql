CREATE procedure InnerProc
is
  begin
    DBMS_OUTPUT.PUT_LINE('Testing');
  end;
/
