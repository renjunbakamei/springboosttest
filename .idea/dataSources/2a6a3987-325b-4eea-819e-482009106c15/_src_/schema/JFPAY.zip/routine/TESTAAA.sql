CREATE PROCEDURE testAAA
BEGIN
  dbms_output.put_line('aaaaa');
END;
/
