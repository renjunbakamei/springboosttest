CREATE PROCEDURE testProc
IS
BEGIN
  dbms_output.put_line(t.table_name);
END;
/
