CREATE procedure test2
begin
  dbms_output.put_line(TO_CHAR(21, '009'));

end;
/
