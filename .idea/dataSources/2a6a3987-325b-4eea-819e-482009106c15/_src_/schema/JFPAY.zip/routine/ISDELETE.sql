CREATE procedure       isDelete
as
begin
  delete MONITOR_REALTIME_RECORD m where m.trans_date<to_char(sysdate-5,'yyyymmdd');
    delete MONITOR_REALTIMEII_RECORD  i where i.trans_date<to_char(sysdate-5,'yyyymmdd');
end;
/
