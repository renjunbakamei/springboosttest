CREATE FUNCTION       CHANNEL_NUMBER (code string)
return string
as
t_number varchar2(32);
begin
  select e.channelnumber into t_number from channelparam e where e.channelid=code and rownum=1;
  return '(' || t_number || ')';
end;


/
